var g_db_data = {"154":1,"147":1,"116":1,"107":1,"113":1,"49":1,"42":1,"29":1};
processScopesDbFile(g_db_data);