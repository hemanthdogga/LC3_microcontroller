rm -rf *.ucdb

make cli TEST_NAME=test_top TEST_SEED=64234323 CODE_COVERAGE_ENABLE=1
make run_cli TEST_NAME=test_top TEST_SEED=45322553 CODE_COVERAGE_ENABLE=1
make run_cli TEST_NAME=test_alu_only TEST_SEED=98213453 CODE_COVERAGE_ENABLE=1
make run_cli TEST_NAME=test_branch TEST_SEED=6543221 CODE_COVERAGE_ENABLE=1
make run_cli TEST_NAME=test_alu_mem_ld TEST_SEED=3093403 CODE_COVERAGE_ENABLE=1
make run_cli TEST_NAME=test_alu_mem_st TEST_SEED=9434783 CODE_COVERAGE_ENABLE=1

#make rank_coverage
make merge_coverage
make coverage_report
make view_coverage
